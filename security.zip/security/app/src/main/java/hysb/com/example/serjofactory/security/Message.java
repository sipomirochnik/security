package hysb.com.example.serjofactory.security;

public class Message {


    //use id;
    private String uid;
    private String messageId;

    private String employeeName;
    private String employeeLastName;
    private int employeePhoneNum;


    //empty ctor requred by fire base
    public Message() { }

    public Message(String uid, String messageId, String employeeName, String employeeLastName, int employeePhoneNum) {
        this.uid = uid;
        this.messageId = messageId;
        this.employeeName = employeeName;
        this.employeeLastName = employeeLastName;
        this.employeePhoneNum = employeePhoneNum;
    }

    public String getUid() {
        return uid;
    }
    public void setUid(String uid) {
        this.uid = uid;
    }
    public String getMessageId() {
        return messageId;
    }
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }
    public String getEmployeeName() {
        return employeeName;
    }
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    public String getEmployeeLastName() {
        return employeeLastName;
    }
    public void setEmployeeLastName(String employeeLastName) {
        this.employeeLastName = employeeLastName;
    }
    public int getEmployeePhoneNum() {
        return employeePhoneNum;
    }
    public void setEmployeePhoneNum(int employeePhoneNum) {
        this.employeePhoneNum = employeePhoneNum;
    }

    @Override
    public String toString() {
        return "Message{" +
                "uid='" + uid + '\'' +
                ", messageId='" + messageId + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", employeeLastName='" + employeeLastName + '\'' +
                ", employeePhoneNum=" + employeePhoneNum +
                '}';
    }
}
