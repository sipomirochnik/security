package hysb.com.example.serjofactory.security;


import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class WeekOrder extends Fragment {

    ImageView ivWeekOrder;

    public WeekOrder() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_week_order, container, false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ivWeekOrder = view.findViewById(R.id.ivWeekOrder);

         //getArguments()alt+ enter twice
        //Bundle bundle = getArguments();
        //if (bundle == null)return;

        //String text = bundle.getString("text");
        //if (text == null)return;
       // tvDisplayText.setText(text);



    }

    public static WeekOrder newInstance(String text) {
        
        Bundle args = new Bundle();
        args.putString("text", text);
        WeekOrder fragment = new WeekOrder();
        fragment.setArguments(args);
        return fragment;
    }

}
